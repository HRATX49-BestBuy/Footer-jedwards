import React from 'react';
import ReactDOM from 'react-dom';
import App from './Main.js'

ReactDOM.render(<App />, document.getElementById('Footer'));


